package fr.eriniumgroups.erinium.jobs.procedures;

public class UpdateOverlayPositionProcedure {
	public static void execute() {
	}
}
