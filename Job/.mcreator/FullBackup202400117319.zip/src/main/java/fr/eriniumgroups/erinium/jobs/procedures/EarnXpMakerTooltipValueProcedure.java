package fr.eriniumgroups.erinium.jobs.procedures;

public class EarnXpMakerTooltipValueProcedure {
	public static String execute() {
		return "Hello\nworld";
	}
}
