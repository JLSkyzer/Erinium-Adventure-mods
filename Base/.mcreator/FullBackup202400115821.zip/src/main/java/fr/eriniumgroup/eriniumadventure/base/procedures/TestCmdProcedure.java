package fr.eriniumgroup.eriniumadventure.base.procedures;

import net.minecraft.world.item.ItemStack;

import java.io.File;

public class TestCmdProcedure {
	public static void execute() {
		File File = new File("");
		ItemStack item = ItemStack.EMPTY;
		ItemStack item2 = ItemStack.EMPTY;
	}
}
