package fr.eriniumgroups.erinium.ericonomy.procedures;

public class TempProcedure {
	public static void execute() {
	}
}
